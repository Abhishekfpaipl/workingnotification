<template>
  <router-view />
</template>

<script>
// App.vue or main component
export default {
  name: 'App',
  
};
</script>