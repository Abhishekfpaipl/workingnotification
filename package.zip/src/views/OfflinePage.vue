 
<template>
    <div>
        <h1>Offline</h1>
        <p>Try connecting to the internet or try again later..</p>
        
    </div>
</template>
  
<script>
export default { 
    name:'OfflinePage'
};
</script>
  